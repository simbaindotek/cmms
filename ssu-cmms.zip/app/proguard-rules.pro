# Default ProGuard rules
-keep class com.ssu.cmms.** { *; }